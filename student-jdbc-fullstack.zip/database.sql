CREATE DATABASE IF NOT EXISTS college;
USE college;

CREATE TABLE IF NOT EXISTS student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    marks INT NOT NULL
);

INSERT INTO student (name, course, marks)
SELECT 'Ravi', 'Java', 85
WHERE NOT EXISTS (SELECT 1 FROM student WHERE name='Ravi' AND course='Java');

INSERT INTO student (name, course, marks)
SELECT 'Priya', 'FSD', 91
WHERE NOT EXISTS (SELECT 1 FROM student WHERE name='Priya' AND course='FSD');
