const API = "api/students";

const form = document.getElementById("studentForm");
const nameInput = document.getElementById("name");
const courseInput = document.getElementById("course");
const marksInput = document.getElementById("marks");
const studentIdInput = document.getElementById("studentId");
const saveBtn = document.getElementById("saveBtn");
const cancelBtn = document.getElementById("cancelBtn");
const table = document.getElementById("studentTable");
const message = document.getElementById("message");

let students = [];

function showMessage(text, error = false) {
    message.textContent = text;
    message.style.color = error ? "crimson" : "green";
}

async function loadStudents() {
    try {
        const response = await fetch(API);

        if (!response.ok) throw new Error("Could not load students");

        students = await response.json();
        renderStudents();
    } catch (error) {
        showMessage(error.message, true);
    }
}

function renderStudents() {
    table.innerHTML = "";

    if (students.length === 0) {
        table.innerHTML = '<tr><td colspan="5">No students found.</td></tr>';
        return;
    }

    students.forEach(student => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${student.id}</td>
            <td>${escapeHtml(student.name)}</td>
            <td>${escapeHtml(student.course)}</td>
            <td>${student.marks}</td>
            <td>
                <div class="actions">
                    <button onclick="editStudent(${student.id})">Edit</button>
                    <button class="danger" onclick="deleteStudent(${student.id})">Delete</button>
                </div>
            </td>
        `;

        table.appendChild(row);
    });
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const data = new URLSearchParams({
        name: nameInput.value,
        course: courseInput.value,
        marks: marksInput.value
    });

    const id = studentIdInput.value;
    const url = id ? `${API}?id=${encodeURIComponent(id)}` : API;
    const method = id ? "PUT" : "POST";

    try {
        const response = await fetch(url, {
            method,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: data
        });

        const result = await response.json();

        if (!response.ok) throw new Error(result.error || "Request failed");

        showMessage(result.message);
        resetForm();
        await loadStudents();

    } catch (error) {
        showMessage(error.message, true);
    }
});

function editStudent(id) {
    const student = students.find(s => s.id === id);
    if (!student) return;

    studentIdInput.value = student.id;
    nameInput.value = student.name;
    courseInput.value = student.course;
    marksInput.value = student.marks;

    saveBtn.textContent = "Update Student";
    cancelBtn.classList.remove("hidden");
    nameInput.focus();
}

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) return;

    try {
        const response = await fetch(`${API}?id=${encodeURIComponent(id)}`, {
            method: "DELETE"
        });

        const result = await response.json();

        if (!response.ok) throw new Error(result.error || "Delete failed");

        showMessage(result.message);
        await loadStudents();

    } catch (error) {
        showMessage(error.message, true);
    }
}

function resetForm() {
    form.reset();
    studentIdInput.value = "";
    saveBtn.textContent = "Add Student";
    cancelBtn.classList.add("hidden");
}

cancelBtn.addEventListener("click", resetForm);
document.getElementById("refreshBtn").addEventListener("click", loadStudents);

loadStudents();
